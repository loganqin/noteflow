# Data policy

This repository intentionally ships **no transaction data, pair scores, model
checkpoints, cached prices, or experiment outputs**. The code is the reusable
implementation of the method; data distribution is handled separately.

## Expected input

The command-line interface accepts one NumPy `.npz` file containing:

- `scores`: a finite one-dimensional floating-point array;
- `counts`: a one-dimensional positive-integer array with one entry per query;
- `row_ids` (optional): unique stable public identifiers used only to break
  ties while constructing the feasible sparse support.

For query `i`, its scores occupy
`scores[sum(counts[:i]):sum(counts[:i+1])]`. Candidate columns are the prefix
`0, ..., counts[i]-1` of a common, stably ordered candidate universe. This
prefix property is part of the paper's setting and is validated before the
method runs.

The graph must admit an injective assignment. Equivalently, after sorting the
candidate counts, the `r`-th count (one-based) must be at least `r`.

## Keep data separate

A recommended local layout is:

```text
parent-directory/
|-- noteflow-open-source/   # this repository
`-- noteflow-data/          # managed separately; never copied into a release
```

The included `.gitignore`, `MANIFEST.in`, and release audit all reject common
data, checkpoint, cache, and result formats. The small arrays written directly
inside tests and examples are synthetic code fixtures, not research data.

## Output

The CLI writes an `.npz` file containing the hard assignment, deposit prices,
soft column masses, adjusted scores, packed complete rankings, ranking offsets,
and JSON diagnostics. Outputs may reveal properties of the supplied inputs and
should follow the same access policy as the input data.

