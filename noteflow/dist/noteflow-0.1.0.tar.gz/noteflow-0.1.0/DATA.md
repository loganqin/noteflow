# Data policy and input format

This repository intentionally contains no research data or generated research
artifacts. Transaction records, pairing labels, trained model parameters,
candidate scores, cached prices, and evaluation outputs must be distributed and
managed separately.

## Required input

The command-line interface accepts a NumPy `.npz` archive with the following
arrays:

| Name | Required | Shape | Constraints |
|---|---|---|---|
| `scores` | Yes | `(sum(counts),)` | One-dimensional and finite |
| `counts` | Yes | `(num_queries,)` | Positive integers |
| `row_ids` | No | `(num_queries,)` | Unique, stable, and mutually comparable |

For query `i`, its scores occupy
`scores[sum(counts[:i]):sum(counts[:i+1])]`. Its legal candidate columns are
the prefix `0, ..., counts[i] - 1` of a common, stable candidate ordering.

The graph must admit an injective assignment covering all queries. For prefix
candidate sets, this is equivalent to the following condition: after sorting
the counts, the count at one-based position `r` must be at least `r`.

`row_ids` are used only to break ties when constructing the deterministic
feasible backbone for sparse price estimation. They are not used as numerical
features. Pairing labels, controller identities, and private correspondence
must not be included in the NoteFlow input.

## Preparing identifiers

NoteFlow returns local integer candidate columns. A data preparation pipeline
should maintain the mapping between these local columns and application-level
identifiers, such as transaction hashes. That mapping remains part of the
separate data release and is not embedded in this code repository.

## Recommended layout

Keep the code and all sensitive or large artifacts as sibling directories:

```text
project-parent/
|-- noteflow/         # this code-only repository
`-- noteflow-data/    # separately governed inputs and outputs
```

For example:

```bash
noteflow \
  --input ../noteflow-data/scores.npz \
  --output ../noteflow-data/noteflow-output.npz \
  --config configs/paper.json
```

The repository's ignore rules, source-distribution manifest, and release audit
exclude common data, checkpoint, cache, and result locations and extensions.
The small numeric arrays written directly in tests and examples are synthetic
code fixtures, not research data.

## Output archive

The CLI writes a compressed `.npz` archive containing the exact assignment,
estimated prices, final soft column masses, adjusted scores, packed complete
rankings, ranking offsets, and JSON diagnostics.

Outputs can reveal properties of the supplied input scores and should follow
the same access, retention, and distribution policy as the input dataset.

## Reproduction boundary

The code release reproduces NoteFlow inference once candidate scores are
available. Reproducing the paper's reported numerical results additionally
requires the separate transaction inputs, trained upstream scorers, complete
score arrays, experiment splits, and evaluation artifacts. Those materials are
not part of this repository.
